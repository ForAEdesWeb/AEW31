DROP TABLE `#__formmaker`;
DROP TABLE `#__formmaker_submits`;
DROP TABLE `#__formmaker_views`;
DROP TABLE `#__formmaker_themes`;
DROP TABLE `#__formmaker_sessions`;
DROP TABLE `#__formmaker_blocked`;
DROP TABLE `#__formmaker_query`;